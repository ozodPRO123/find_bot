# from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
# tugma = ReplyKeyboardMarkup(
#     keyboard=[
#         [
#             KeyboardButton('FOODS 🥘'),
#             KeyboardButton('ANIMALS 🐻‍❄️')
#         ],
#         [
#             KeyboardButton('SMOKING 🚬'),
#             KeyboardButton('Car 🏎')
#         ],
#         [
#             KeyboardButton('LGBT 🏳️‍🌈')
#         ]
#     ], resize_keyboard=True
# )



