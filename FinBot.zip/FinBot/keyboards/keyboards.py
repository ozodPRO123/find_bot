from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
tugma = ReplyKeyboardMarkup(
    keyboard=[
        [
            KeyboardButton('CAR🏎'),
            KeyboardButton('ANIMALS🙊')
        ],
        [
            KeyboardButton('FOODS🥙')
        ]
    ],resize_keyboard=True
)
