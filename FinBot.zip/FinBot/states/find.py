from aiogram.dispatcher.filters.state import State, StatesGroup


class FindState(StatesGroup):
    send = State()
    claim = State()