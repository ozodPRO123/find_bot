from loader import dp
from random import choice
from states.find import FindState
from aiogram.dispatcher import FSMContext
from aiogram.types import Message
import os



@dp.message_handler(text='CAR🏎')
async def cmd_start_game(message: Message, state: FSMContext):
    await FindState.send.set()
    items_list = os.listdir('photo')

    bot_choice = choice(items_list)
    element = bot_choice.split('.')[0]
    word = bot_choice[0]
    len_word = len(element)

    photo = open(f'photo/{bot_choice}', "rb")

    await message.answer_photo(
        photo=photo,
        caption=f'xurmatli {message.from_user.full_name}\n'
                f'Siz CAR tugmasini  ustiga bostingiz\n'
                f'Mashinaning bosh harfi 👉"{word}"👈\n'
                f'Mashina 👉"{len_word}"👈 ta harfdan iborat\n'
                f'Rasmdagi mashinani turini toping'
    )
    async with state.proxy() as data:
        data['word'] = element
    photo.close()
    await FindState.next()


@dp.message_handler(text='ANIMALS🙊')
async def cmd_start_game(message: Message, state: FSMContext):
    await FindState.send.set()
    items_list = os.listdir('photos')

    bot_choice = choice(items_list)
    element = bot_choice.split('.')[0]
    word = bot_choice[0]
    len_word = len(element)

    photo = open(f'photos/{bot_choice}', "rb")

    await message.answer_photo(
        photo=photo,
        caption=f'Xurmatli {message.from_user.full_name}\n'
                f'Siz ANIMALS tugmasini ustiga bostingiz\n'
                f'Rasimdagi hayvonning bosh harfi 👉"{word}"👈\n'
                f'Rasimdagi hayvon 👉"{len_word}"👈 ta harfdan iborat\n'
                f'Rasmdagi hayvonnig turini toping'
    )
    async with state.proxy() as data:
        data['word'] = element
    photo.close()
    await FindState.next()

@dp.message_handler(text='FOODS🥙')
async def cmd_start_game(message: Message, state: FSMContext):
    await FindState.send.set()
    items_list = os.listdir('photor')

    bot_choice = choice(items_list)
    element = bot_choice.split('.')[0]
    word = bot_choice[0]
    len_word = len(element)

    photo = open(f'photor/{bot_choice}',"rb")

    await message.answer_photo(
        photo=photo,
        caption=f'Xurmatli {message.from_user.full_name}\n'
                f'Siz FOODS tugmasini ustiga bostingiz\n'
                f'Rasimdagi mazzali taomning bosh harfi 👉"{word}"👈\n'
                f'Rasimdagi taom 👉"{len_word}"👈 ta harfdan iborat\n'
                f'Rasmdagi mazzali taom turini toping'
    )
    async with state.proxy() as data:
        data['word'] = element
    photo.close()
    await FindState.next()


@dp.message_handler(state=FindState.claim)
async def cmd_winner_detect(message: Message, state: FSMContext):
    async with state.proxy() as data:
        pass
    print(message.text, data['word'])
    if message.text.lower() == data['word'].lower():
        await message.answer(f'{message.from_user.full_name} 👏🥳tabriklaymiz siz yutingiz\n'
                             f'Yana rasmdagi elementni ismini topmoqchi bo`lsangiz 👉/start👈 tugmasini ustiga bosing')
        await state.finish()

    else:
        await message.answer('Xato kirittingiz!\n'
                             'iltimos boshqattan urinib ko`ring')
