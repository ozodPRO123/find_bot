# from loader import dp
# from aiogram.types import Message
# from random import choice
#
# @dp.message_handler(text="FOODS 🥘")
# async def cmd_send(message: Message):
#     photos = ['p1.jpg','food2.jpg','food3.jpg','food4.jpg','food5.jpg']
#     p = choice(photos)
#     photo = open(f"photo/{p}", 'rb')
#
#     await message.answer_photo(caption='Yemoqchi bo`lsang ye 😜😜', photo=photo)
#     photo.close()
#
# @dp.message_handler(text="ANIMALS 🐻‍❄️")
# async def cmd_send(message: Message):
#     photos = ['animal1.jpg','animal2.jpg','animal3.jpg','animal4.jpg','animal5.jpg','animal6.jpg','animal7.jpg']
#     p = choice(photos)
#     photo = open(f"photo/{p}", 'rb')
#
#     await message.answer_photo(caption='Hayvonlarni ko`rib kayf qi', photo=photo)
#     photo.close()
#
# @dp.message_handler(text="SMOKING 🚬")
# async def cmd_send(message: Message):
#     photos = ['smoking1.jpg','smoking2.jpg','smoking3.jpg','smoking4.jpg']
#     p = choice(photos)
#     photo = open(f"photo/{p}", 'rb')
#
#     await message.answer_photo(caption='Bu akangni qizi 😚😚\n'
#                                        'o`zi sigaret chakmaydi lekin qizi chakadi', photo=photo)
#     photo.close()
#
#
# @dp.message_handler(text="Car 🏎")
# async def cmd_send(message: Message):
#     photos = ['car1.jpg','car2.jpg','bmw.jpg']
#     p = choice(photos)
#     photo = open(f"photo/{p}", 'rb')
#
#     await message.answer_photo(caption='Akangning moshin kalektsiyasini tomosha qil 🚙🚙', photo=photo)
#     photo.close()
#
# @dp.message_handler(text="LGBT 🏳️‍🌈")
# async def cmd_send(message: Message):
#     photos = ['LGBT.jpg']
#     p = choice(photos)
#     photo = open(f"photo/{p}", 'rb')
#
#     await message.answer_photo(caption='Bu Dalerning yaxshi ko`rgan qizi 🤣🤣', photo=photo)
#     photo.close()
