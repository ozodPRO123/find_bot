from loader import dp
from aiogram.types import Message
from aiogram.dispatcher.filters.builtin import CommandStart
from keyboards.keyboards import tugma

@dp.message_handler(CommandStart())
async def cmd_start(mesage: Message):
    if mesage.chat.type == 'private':
        await mesage.answer(f'Assalomu aleykum xurmatli{mesage.from_user.full_name}\n'
                            f'Rasimni ismini top botiga xush kelibsiz\n'
                            f'Qaysi turdagi elementning ismini topmoqchi bo`lsangiz\n'
                            f'Pastdagi👇 tugmani tanlab bosing\n'
                            f'Agar mabodo bod sizga yoqmasa pashol na**uy va idin na**uy', reply_markup=tugma)
    elif mesage.chat.type == 'supergroup':
        await mesage.answer(f'Salom {mesage.chat.full_name} aholisi\n'
                            f'Sizlarni ko`rganimdan xursandman\n'
                            f'/start kalit so`zini ustiga bosing va element ismini toping\n'                    
                            f'qisqasi {mesage.from_user.full_name} *** bosti', reply_markup=tugma)